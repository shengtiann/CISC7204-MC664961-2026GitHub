# CISC7204 Assignment 02 - Module 04 Lab 02
Dash Basics: HTML and Core Components

| | |
|---|---|
| **Student ID** | MC664961 |
| **Student Name** | SHENG TIAN |
| **Course** | CISC7204 - Data Science Programming (Assignment 02) |
| **Project space** | `m04_lab02` |
| **Run** | `python app.py` then open <http://127.0.0.1:8052> |
| **Dataset** | `data/airline_data.csv (US domestic airline reporting data, 27,000 rows)` |

## What this project demonstrates

- the two Dash component families: `dash.html.*` (one component per HTML tag) and `dash.dcc.*` (rich, interactive components)
- building a page structure from `html.Div`, `html.H1`, `html.P`, `html.Hr`, `html.B`, `html.Span`
- placing Plotly figures on a dashboard with `dcc.Graph(figure=...)`
- inline CSS on components (`style={...}`) to build a card layout without a stylesheet
- the difference between a *layout* (declared once) and a *callback* (added in Lab 03/04)

## Files

| File | Purpose |
|---|---|
| `app.py` | The whole application: data load, three Plotly figures, layout |
| `CISC7204 Assgn02 Module 04 - Lab02 LabRecord MC664961 SHENG TIAN.ipynb` | The executed lab record: data, figures, callback output, live screenshot |
| `data/airline_data.csv` | Dataset used by the application (included so it runs offline) |
| `screenshots/dashboard.png` | Real browser capture(s) of the running dashboard |
| `requirements.txt` | `dash`, `pandas`, `plotly` |
| `README.md` | This file |


## The lab record notebook

`CISC7204 Assgn02 Module 04 - Lab02 LabRecord MC664961 SHENG TIAN.ipynb` is an **executed** Jupyter notebook that sits next to `app.py`. It exists
because a Dash application is a web server rather than a notebook: the application has to stay
in `app.py`, but the *work* still needs to be readable in notebook form.

The record

1. loads the same dataset and prints the shape / sample the application uses,
2. imports `app` as a module (this runs the data layer and the layout, but **not** the server,
   because `app.run()` is behind `if __name__ == "__main__":`),
3. calls the callback function directly and displays the very figures it returns, and
4. embeds the real browser capture(s) from `screenshots/` that were taken while the server was
   running.

So the marker gets both: a project space that runs, and a notebook in which every step and its
output are visible.

## How to run

```bash
# 1. (optional) create an environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. start the dashboard
python app.py

# 3. open the address printed in the terminal
#    http://127.0.0.1:8052
```

The application runs on port **8052**; change the `port=` argument in `app.py` if that
port is already in use. Press `Ctrl+C` in the terminal to stop it.

## What the screenshots in the forum show

- The dashboard as rendered by a browser at http://127.0.0.1:8052.

## Notes

- `dash.Dash.run()` is used instead of the older `run_server()`, which Dash 3 removed.
- The dataset is included in `data/` so the application runs offline.
- Every figure is a normal Plotly figure, so any chart here can be exported with
  `fig.write_html(...)` for a static report.
