"""CISC7204 Assignment 02 - Module 04 Lab 02
Dash Basics: HTML and Core Components.

A pure-layout Dash application (no callbacks yet). It shows the two component
families that every later dashboard is built from:

  * dash.html  -> one component per HTML tag (Div, H1, H2, P, Br, Hr, Span)
  * dash.dcc   -> the interactive / rich components (Graph, Dropdown, Input)

Run with:  python app.py      then open http://127.0.0.1:8050
"""
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html

DATA = "data/airline_data.csv"

# --------------------------------------------------------------------------- #
# 1. data
# --------------------------------------------------------------------------- #
airline_data = pd.read_csv(
    DATA,
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str})

# 27,000 rows is far more than a static overview needs; a fixed random sample keeps the
# page fast and the pie chart readable (random_state makes the result reproducible).
data = airline_data.sample(n=500, random_state=42)

# --------------------------------------------------------------------------- #
# 2. figures - every Plotly figure can be handed straight to dcc.Graph
# --------------------------------------------------------------------------- #
pie_fig = px.pie(
    data, values="Flights", names="DistanceGroup",
    title="Proportion of distance group (250 mile interval) by flights")
pie_fig.update_traces(textposition="inside", textinfo="percent+label")

bar_fig = px.bar(
    data.groupby("Reporting_Airline")["Flights"].sum().sort_values(ascending=False).head(10)
        .reset_index(),
    x="Reporting_Airline", y="Flights",
    title="Top 10 reporting airlines in the sample")
bar_fig.update_layout(xaxis_title="Reporting airline", yaxis_title="Flights")

hist_fig = px.histogram(
    data, x="ArrDelay", nbins=40,
    title="Distribution of arrival delay in the sample")
hist_fig.update_layout(xaxis_title="Arrival delay (minutes)", yaxis_title="Records")

# --------------------------------------------------------------------------- #
# 3. layout - html.* for structure, dcc.* for the interactive pieces
# --------------------------------------------------------------------------- #
app = Dash(__name__)

CARD = {"backgroundColor": "#ffffff", "borderRadius": "10px", "padding": "18px",
        "marginBottom": "18px", "boxShadow": "0 1px 4px rgba(0,0,0,0.10)"}

app.layout = html.Div(
    style={"backgroundColor": "#eef2f7", "minHeight": "100vh",
           "fontFamily": "Helvetica, Arial, sans-serif", "padding": "24px 32px"},
    children=[

        # ---- header block: H1 + P + Hr -------------------------------- #
        html.Div(style=CARD, children=[
            html.H1("Airline Dashboard",
                    style={"textAlign": "center", "color": "#503D36",
                           "fontSize": 34, "marginBottom": "6px"}),
            html.P("Proportion of distance group (250 mile distance interval group) by flights.",
                   style={"textAlign": "center", "color": "#F57241",
                          "fontSize": 16, "marginTop": "0"}),
            html.Hr(style={"border": "none", "borderTop": "1px solid #dde3ea"}),
            html.P([
                "Sample of ",
                html.B(html.Span(f"{len(data):,}")),
                " flight records drawn from the US domestic airline reporting dataset "
                f"({len(airline_data):,} records, 1987-2020). ",
                html.Br(),
                html.I("Built with Dash HTML components (html.Div, html.H1, html.P, html.Hr, "
                       "html.B, html.Span) and core components (dcc.Graph)."),
            ], style={"color": "#4a5568", "fontSize": 14, "lineHeight": "1.6"}),
        ]),

        # ---- one dcc.Graph per figure --------------------------------- #
        html.Div(style=CARD, children=[dcc.Graph(figure=pie_fig)]),

        html.Div(style={"display": "flex", "gap": "18px"}, children=[
            html.Div(style={**CARD, "flex": "1"}, children=[dcc.Graph(figure=bar_fig)]),
            html.Div(style={**CARD, "flex": "1"}, children=[dcc.Graph(figure=hist_fig)]),
        ]),

        # ---- footer --------------------------------------------------- #
        html.Div(style={"textAlign": "center", "color": "#718096", "fontSize": 12},
                 children=[html.P("CISC7204 Assignment 02 - Module 04 Lab 02 - "
                                  "Dash Basics: HTML and Core Components - MC664961 SHENG TIAN")]),
    ])


if __name__ == "__main__":
    # Dash >= 3: app.run_server() was replaced by app.run()
    app.run(debug=False, port=8052)
