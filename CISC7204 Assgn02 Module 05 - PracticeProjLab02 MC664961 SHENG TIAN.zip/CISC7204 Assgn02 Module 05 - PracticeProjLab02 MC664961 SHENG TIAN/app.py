"""CISC7204 Assignment 02 - Module 05 Practice Project - Lab 02
Creating a Dashboard: Australia Wildfire Activities.

Two inputs drive two charts:

    Region (radio items)  ->  trend of the average estimated fire area per month
    Year (dropdown)       ->  fire area vs fire brightness for that region and year

Run with:  python app.py      then open http://127.0.0.1:8053
"""
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

# --------------------------------------------------------------------------- #
# 1. data
# --------------------------------------------------------------------------- #
df = pd.read_csv("data/Historical_Wildfires.csv")

# The raw file has one row per region per day; the charts need month and year.
# Dates in the file are month/day/year (e.g. 1/13/2005), so parse them explicitly.
df["Date"] = pd.to_datetime(df["Date"], format="%m/%d/%Y")
df["Month"] = df["Date"].dt.month_name()
df["Year"] = df["Date"].dt.year

MONTH_ORDER = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]
REGIONS = ["NSW", "NT", "QL", "SA", "TA", "VI", "WA"]

CARD = {"backgroundColor": "#ffffff", "borderRadius": "10px", "padding": "14px",
        "marginBottom": "16px", "boxShadow": "0 1px 4px rgba(0,0,0,0.10)"}

# --------------------------------------------------------------------------- #
# 2. layout
# --------------------------------------------------------------------------- #
app = Dash(__name__)

app.layout = html.Div(
    style={"backgroundColor": "#eef2f7", "minHeight": "100vh",
           "fontFamily": "Helvetica, Arial, sans-serif", "padding": "24px 32px"},
    children=[
        html.Div(style=CARD, children=[
            html.H1("Australia Wildfire Dashboard",
                    style={"textAlign": "center", "color": "#503D36",
                           "fontSize": 30, "marginBottom": "4px"}),
            html.P("Estimated fire area and fire brightness by region and year (2005 - 2020).",
                   style={"textAlign": "center", "color": "#F57241", "fontSize": 15,
                          "marginTop": "0"}),
            html.Hr(style={"border": "none", "borderTop": "1px solid #dde3ea"}),

            html.Div([
                # ---- input 1: the region --------------------------- #
                html.Div([
                    html.H2("Select Region:", style={"marginRight": "2em"}),
                    dcc.RadioItems(options=REGIONS, value="NSW", id="region",
                                   inline=True),
                ], style={"marginBottom": "14px"}),

                # ---- input 2: the year ----------------------------- #
                html.Div([
                    html.H2("Select Year:", style={"marginRight": "2em"}),
                    dcc.Dropdown(options=sorted(df["Year"].unique()), value=2005,
                                 id="year", clearable=False, style={"width": "180px"}),
                ]),
            ], style={"display": "flex", "gap": "40px", "justifyContent": "center",
                      "alignItems": "flex-start"}),
        ]),

        # ---- two output divisions -------------------------------- #
        html.Div(style={"display": "flex", "gap": "16px"}, children=[
            html.Div(style={**CARD, "flex": "1"}, children=[html.Div(id="plot1")]),
            html.Div(style={**CARD, "flex": "1"}, children=[html.Div(id="plot2")]),
        ]),

        html.Div(style={"textAlign": "center", "color": "#718096", "fontSize": 12},
                 children=[html.P("CISC7204 Assignment 02 - Module 05 Practice Lab 02 - "
                                  "MC664961 SHENG TIAN")]),
    ])


# --------------------------------------------------------------------------- #
# 3. callbacks - one per output, each with its own Input
# --------------------------------------------------------------------------- #
@app.callback(Output("plot1", "children"), [Input("region", "value")])
def display_plot1(region):
    """Average estimated fire area per month, for the selected region (all years)."""
    monthly = (df[df["Region"] == region]
               .groupby("Month")
               .agg(avg_area=("Estimated_fire_area", "mean"))
               .reindex(MONTH_ORDER)
               .reset_index())

    fig = px.line(monthly, x="Month", y="avg_area", markers=True,
                  title=f"Average estimated fire area per month - {region}",
                  labels={"Month": "Month", "avg_area": "Avg fire area (km2)"})
    fig.update_traces(line_color="#c0392b", line_width=3)
    fig.update_layout(height=420, margin=dict(l=40, r=20, t=60, b=40))
    return dcc.Graph(figure=fig)


@app.callback(Output("plot2", "children"),
              [Input("region", "value"), Input("year", "value")])
def display_plot2(region, year):
    """Fire area vs fire brightness for one region in one year."""
    sub = df[(df["Region"] == region) & (df["Year"] == int(year))]

    if sub.empty:
        return html.P(f"No records for {region} in {year}.")

    fig = px.scatter(sub, x="Estimated_fire_area", y="Mean_estimated_fire_brightness",
                     size="Count", color="Mean_confidence",
                     color_continuous_scale="Viridis",
                     title=f"Fire area vs brightness - {region}, {year}",
                     labels={"Estimated_fire_area": "Estimated fire area (km2)",
                             "Mean_estimated_fire_brightness": "Mean fire brightness",
                             "Mean_confidence": "Confidence"})
    fig.update_layout(height=420, margin=dict(l=40, r=20, t=60, b=40))
    return dcc.Graph(figure=fig)


if __name__ == "__main__":
    app.run(debug=False, port=8053)
