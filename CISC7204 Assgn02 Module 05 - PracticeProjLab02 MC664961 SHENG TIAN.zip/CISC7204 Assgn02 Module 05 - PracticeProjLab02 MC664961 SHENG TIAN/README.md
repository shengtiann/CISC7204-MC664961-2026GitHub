# CISC7204 Assignment 02 - Module 05 Practice Project Lab 02
Creating a Dashboard: Australia Wildfire Activities

| | |
|---|---|
| **Student ID** | MC664961 |
| **Student Name** | SHENG TIAN |
| **Course** | CISC7204 - Data Science Programming (Assignment 02) |
| **Project space** | `m05_practice_lab02` |
| **Run** | `python app.py` then open <http://127.0.0.1:8053> |
| **Dataset** | `data/Historical_Wildfires.csv (Australia, 2005-2020, one row per region per day)` |

## What this project demonstrates

- two independent callbacks, each with its own `Input` and `Output`
- `dcc.RadioItems` to pick a region and `dcc.Dropdown` to pick a year
- deriving month and year from a date column before aggregating
- forcing a month order with `reindex` so the line chart runs January -> December
- a size- and colour-encoded scatter (fire area vs brightness, bubble = fire count)

## Files

| File | Purpose |
|---|---|
| `app.py` | The application: layout, region radio items, year dropdown, two callbacks |
| `CISC7204 Assgn02 Module 05 - PracticeProjLab02 LabRecord MC664961 SHENG TIAN.ipynb` | The executed lab record: data, figures, callback output, live screenshot |
| `data/Historical_Wildfires.csv` | Dataset used by the application (included so it runs offline) |
| `screenshots/nsw_2005.png, screenshots/qld_2019.png` | Real browser capture(s) of the running dashboard |
| `requirements.txt` | `dash`, `pandas`, `plotly` |
| `README.md` | This file |


## The lab record notebook

`CISC7204 Assgn02 Module 05 - PracticeProjLab02 LabRecord MC664961 SHENG TIAN.ipynb` is an **executed** Jupyter notebook that sits next to `app.py`. It exists
because a Dash application is a web server rather than a notebook: the application has to stay
in `app.py`, but the *work* still needs to be readable in notebook form.

The record

1. loads the same dataset and prints the shape / sample the application uses,
2. imports `app` as a module (this runs the data layer and the layout, but **not** the server,
   because `app.run()` is behind `if __name__ == "__main__":`),
3. calls the callback function directly and displays the very figures it returns, and
4. embeds the real browser capture(s) from `screenshots/` that were taken while the server was
   running.

So the marker gets both: a project space that runs, and a notebook in which every step and its
output are visible.

## How to run

```bash
# 1. (optional) create an environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. start the dashboard
python app.py

# 3. open the address printed in the terminal
#    http://127.0.0.1:8053
```

The application runs on port **8053**; change the `port=` argument in `app.py` if that
port is already in use. Press `Ctrl+C` in the terminal to stop it.

## What the screenshots in the forum show

- The dashboard for the default selection (NSW, 2005) and for another region/year, showing both charts redrawn.

## Notes

- `dash.Dash.run()` is used instead of the older `run_server()`, which Dash 3 removed.
- The dataset is included in `data/` so the application runs offline.
- Every figure is a normal Plotly figure, so any chart here can be exported with
  `fig.write_html(...)` for a static report.
