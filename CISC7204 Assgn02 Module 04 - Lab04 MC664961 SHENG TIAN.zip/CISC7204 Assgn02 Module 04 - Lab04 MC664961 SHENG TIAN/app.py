"""CISC7204 Assignment 02 - Module 04 Lab 04
Flight Delay Time Statistics Dashboard.

Five line charts, one per delay category, for the year chosen in the input box:

    CarrierDelay | WeatherDelay | NASDelay | SecurityDelay | LateAircraftDelay

This is the canonical Dash callback pattern: one Input (the year), five Outputs (the
five dcc.Graph children), and a function that recomputes the five figures on every change.

Run with:  python app.py      then open http://127.0.0.1:8054
"""
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

# --------------------------------------------------------------------------- #
# 1. data
# --------------------------------------------------------------------------- #
airline_data = pd.read_csv(
    "data/airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str})

# The delay breakdown columns are only populated from 2005 onwards.
airline_data = airline_data[airline_data["Year"].between(2005, 2020)]

YEAR = 2010
CARD = {"backgroundColor": "#ffffff", "borderRadius": "10px", "padding": "10px",
        "marginBottom": "14px", "boxShadow": "0 1px 4px rgba(0,0,0,0.10)"}

# --------------------------------------------------------------------------- #
# 2. layout  (html.* for structure, dcc.* for the interactive components)
# --------------------------------------------------------------------------- #
app = Dash(__name__)

app.layout = html.Div(
    style={"backgroundColor": "#eef2f7", "minHeight": "100vh",
           "fontFamily": "Helvetica, Arial, sans-serif", "padding": "24px 32px"},
    children=[
        html.Div(style=CARD, children=[
            html.H1("Flight Delay Time Statistics Dashboard",
                    style={"textAlign": "center", "color": "#503D36",
                           "fontSize": 30, "marginBottom": "4px"}),
            html.P("Average delay time in minutes by reporting airline, per month "
                   "of the selected year - one chart per delay category.",
                   style={"textAlign": "center", "color": "#F57241", "fontSize": 15,
                          "marginTop": "0"}),
            html.Hr(style={"border": "none", "borderTop": "1px solid #dde3ea"}),

            # ---- the only user input: the year ---------------- #
            html.Div([
                html.H2("Input Year: ", style={"fontSize": 20, "marginRight": "1em",
                                               "display": "inline-block"}),
                dcc.Input(id="input-year", value=str(YEAR), type="number",
                          min=2005, max=2020, step=1, debounce=True,
                          style={"height": "40px", "width": "140px", "fontSize": 20,
                                 "textAlign": "center"}),
            ], style={"textAlign": "center", "padding": "6px 0 14px 0"}),
        ]),

        # ---- five empty divisions, each filled by the callback ------- #
        html.Div(style=CARD, children=[html.Div(id="plot1")]),
        html.Div(style=CARD, children=[html.Div(id="plot2")]),
        html.Div(style=CARD, children=[html.Div(id="plot3")]),
        html.Div(style=CARD, children=[html.Div(id="plot4")]),
        html.Div(style=CARD, children=[html.Div(id="plot5")]),

        html.Div(style={"textAlign": "center", "color": "#718096", "fontSize": 12},
                 children=[html.P("CISC7204 Assignment 02 - Module 04 Lab 04 - "
                                  "MC664961 SHENG TIAN")]),
    ])


# --------------------------------------------------------------------------- #
# 3. callback
# --------------------------------------------------------------------------- #
@app.callback(
    [Output("plot1", "children"), Output("plot2", "children"), Output("plot3", "children"),
     Output("plot4", "children"), Output("plot5", "children")],
    [Input("input-year", "value")])
def compute_delay_charts(entered_year):
    """Recompute the five delay charts for the year typed in the input box."""
    year = int(entered_year)
    df = airline_data[airline_data["Year"] == year]

    if df.empty:                     # guard: the input box is free text
        return [html.P(f"No records for {year}.")] * 5

    def delay_fig(column, title, color):
        avg = (df.groupby(["Month", "Reporting_Airline"])[column]
                 .mean().reset_index())
        fig = px.line(avg, x="Month", y=column, color="Reporting_Airline",
                      title=title, markers=True,
                      labels={"Month": "Month", column: "Average delay (min)",
                              "Reporting_Airline": "Airline"})
        fig.update_layout(height=380, margin=dict(l=40, r=20, t=50, b=40),
                          title_font_color=color,
                          xaxis=dict(tickmode="linear", tick0=1, dtick=1),
                          legend=dict(orientation="h", y=-0.25))
        return dcc.Graph(figure=fig)

    return [
        delay_fig("CarrierDelay", f"Average carrier delay time (minutes) by airline - {year}", "#d62728"),
        delay_fig("WeatherDelay", f"Average weather delay time (minutes) by airline - {year}", "#1f77b4"),
        delay_fig("NASDelay", f"Average NAS delay time (minutes) by airline - {year}", "#2ca02c"),
        delay_fig("SecurityDelay", f"Average security delay time (minutes) by airline - {year}", "#9467bd"),
        delay_fig("LateAircraftDelay", f"Average late aircraft delay time (minutes) by airline - {year}", "#ff7f0e"),
    ]


if __name__ == "__main__":
    app.run(debug=False, port=8054)
