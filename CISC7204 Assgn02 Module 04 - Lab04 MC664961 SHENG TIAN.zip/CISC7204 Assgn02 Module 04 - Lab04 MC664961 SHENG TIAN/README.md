# CISC7204 Assignment 02 - Module 04 Lab 04
Flight Delay Time Statistics Dashboard

| | |
|---|---|
| **Student ID** | MC664961 |
| **Student Name** | SHENG TIAN |
| **Course** | CISC7204 - Data Science Programming (Assignment 02) |
| **Project space** | `m04_lab04` |
| **Run** | `python app.py` then open <http://127.0.0.1:8054> |
| **Dataset** | `data/airline_data.csv (US domestic airline reporting data)` |

## What this project demonstrates

- wiring **one** `Input` (the year box) to **five** `Output` components in a single `@app.callback`
- aggregating inside a callback (`groupby(['Month','Reporting_Airline']).mean()`) so the charts follow the user's choice
- one chart per delay category: carrier, weather, NAS, security and late-aircraft delay
- guarding the callback against an empty selection (the input box is free text)

## Files

| File | Purpose |
|---|---|
| `app.py` | The application: layout, year input, and the five-output callback |
| `CISC7204 Assgn02 Module 04 - Lab04 LabRecord MC664961 SHENG TIAN.ipynb` | The executed lab record: data, figures, callback output, live screenshot |
| `data/airline_data.csv` | Dataset used by the application (included so it runs offline) |
| `screenshots/year2010.png, screenshots/year2015.png` | Real browser capture(s) of the running dashboard |
| `requirements.txt` | `dash`, `pandas`, `plotly` |
| `README.md` | This file |


## The lab record notebook

`CISC7204 Assgn02 Module 04 - Lab04 LabRecord MC664961 SHENG TIAN.ipynb` is an **executed** Jupyter notebook that sits next to `app.py`. It exists
because a Dash application is a web server rather than a notebook: the application has to stay
in `app.py`, but the *work* still needs to be readable in notebook form.

The record

1. loads the same dataset and prints the shape / sample the application uses,
2. imports `app` as a module (this runs the data layer and the layout, but **not** the server,
   because `app.run()` is behind `if __name__ == "__main__":`),
3. calls the callback function directly and displays the very figures it returns, and
4. embeds the real browser capture(s) from `screenshots/` that were taken while the server was
   running.

So the marker gets both: a project space that runs, and a notebook in which every step and its
output are visible.

## How to run

```bash
# 1. (optional) create an environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. start the dashboard
python app.py

# 3. open the address printed in the terminal
#    http://127.0.0.1:8054
```

The application runs on port **8054**; change the `port=` argument in `app.py` if that
port is already in use. Press `Ctrl+C` in the terminal to stop it.

## What the screenshots in the forum show

- The dashboard for the default year (2010) and for a second year after typing a new value, showing the five delay charts recomputed by the callback.

## Notes

- `dash.Dash.run()` is used instead of the older `run_server()`, which Dash 3 removed.
- The dataset is included in `data/` so the application runs offline.
- Every figure is a normal Plotly figure, so any chart here can be exported with
  `fig.write_html(...)` for a static report.
