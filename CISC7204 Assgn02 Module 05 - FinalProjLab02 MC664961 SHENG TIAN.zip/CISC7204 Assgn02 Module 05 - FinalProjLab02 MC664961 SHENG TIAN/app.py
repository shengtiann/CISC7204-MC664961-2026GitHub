"""CISC7204 Assignment 02 - Module 05 Final Project - Lab 02
US Domestic Airline Flights Performance - a Plotly + Dash dashboard.

The user picks a report type and a year and presses Submit; the callback then fills five
divisions with five different charts:

  Report type 1 - Yearly Airline Performance Report
        treemap (flights to each state by airline) | pie (share by origin state)
        choropleth (flights per origin state)      | bar  (cancellations by month/code)
        line (average air time by month/airline)

  Report type 2 - Yearly Airline Delay Report
        five line charts: carrier / weather / NAS / security / late-aircraft delay

Run with:  python app.py      then open http://127.0.0.1:8055
"""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, Input, Output, State, dcc, html

# --------------------------------------------------------------------------- #
# 1. data
# --------------------------------------------------------------------------- #
airline_data = pd.read_csv(
    "data/airline_data.csv",
    encoding="ISO-8859-1",
    dtype={"Div1Airport": str, "Div1TailNum": str,
           "Div2Airport": str, "Div2TailNum": str})

YEAR_LIST = [y for y in range(2005, 2021)]
CARD = {"backgroundColor": "#ffffff", "borderRadius": "10px", "padding": "12px",
        "marginBottom": "14px", "boxShadow": "0 1px 4px rgba(0,0,0,0.10)"}


# --------------------------------------------------------------------------- #
# 2. data-preparation helpers (kept out of the callback body for readability)
# --------------------------------------------------------------------------- #
def compute_data_choice_1(df):
    """Frames for the five performance charts."""
    tree_data = df.groupby(["DestState", "Reporting_Airline"])["Flights"].sum().reset_index()
    pie_data = df.groupby(["OriginState"])["Flights"].sum().reset_index()
    map_data = df.groupby(["OriginState"])["Flights"].sum().reset_index()
    bar_data = df.groupby(["Month", "CancellationCode"])["Flights"].sum().reset_index()
    line_data = df.groupby(["Month", "Reporting_Airline"])["AirTime"].mean().reset_index()
    return tree_data, pie_data, map_data, bar_data, line_data


def compute_data_choice_2(df):
    """Frames for the five delay charts."""
    return (df.groupby(["Month", "Reporting_Airline"])["CarrierDelay"].mean().reset_index(),
            df.groupby(["Month", "Reporting_Airline"])["WeatherDelay"].mean().reset_index(),
            df.groupby(["Month", "Reporting_Airline"])["NASDelay"].mean().reset_index(),
            df.groupby(["Month", "Reporting_Airline"])["SecurityDelay"].mean().reset_index(),
            df.groupby(["Month", "Reporting_Airline"])["LateAircraftDelay"].mean().reset_index())


# --------------------------------------------------------------------------- #
# 3. layout
# --------------------------------------------------------------------------- #
app = Dash(__name__)
app.config.suppress_callback_exceptions = True

app.layout = html.Div(
    style={"backgroundColor": "#eef2f7", "minHeight": "100vh",
           "fontFamily": "Helvetica, Arial, sans-serif", "padding": "24px 32px"},
    children=[
        html.Div(style=CARD, children=[
            html.H1("US Domestic Airline Flights Performance",
                    style={"textAlign": "center", "color": "#503D36",
                           "fontSize": 30, "marginBottom": "4px"}),
            html.P("Choose a report type and a year, then press Submit.",
                   style={"textAlign": "center", "color": "#F57241", "fontSize": 15,
                          "marginTop": "0"}),
            html.Hr(style={"border": "none", "borderTop": "1px solid #dde3ea"}),

            html.Div(style={"display": "flex", "gap": "40px", "justifyContent": "center",
                            "alignItems": "center", "flexWrap": "wrap",
                            "padding": "10px 0"}, children=[
                html.Div([
                    html.H2("Report Type:", style={"fontSize": 18, "marginRight": "8px",
                                                   "display": "inline-block"}),
                    dcc.Dropdown(
                        id="chart-type",
                        options=[{"label": "Yearly Airline Performance Report", "value": 1},
                                 {"label": "Yearly Airline Delay Report", "value": 2}],
                        value=1, clearable=False, style={"width": "330px"}),
                ], style={"display": "inline-block"}),

                html.Div([
                    html.H2("Year:", style={"fontSize": 18, "marginRight": "8px",
                                            "display": "inline-block"}),
                    dcc.Dropdown(id="input-year", options=YEAR_LIST, value=2010,
                                 clearable=False, style={"width": "130px"}),
                ], style={"display": "inline-block"}),

                html.Button("Submit", id="submit-button", n_clicks=0,
                            style={"height": "44px", "width": "120px", "fontSize": 16,
                                   "backgroundColor": "#503D36", "color": "white",
                                   "border": "none", "borderRadius": "6px",
                                   "cursor": "pointer"}),
            ]),
        ]),

        html.Div(style=CARD, children=[html.Div(id="plot1")]),
        html.Div(style=CARD, children=[html.Div(id="plot2")]),
        html.Div(style=CARD, children=[html.Div(id="plot3")]),
        html.Div(style=CARD, children=[html.Div(id="plot4")]),
        html.Div(style=CARD, children=[html.Div(id="plot5")]),

        html.Div(style={"textAlign": "center", "color": "#718096", "fontSize": 12},
                 children=[html.P("CISC7204 Assignment 02 - Module 05 Final Project Lab 02 - "
                                  "MC664961 SHENG TIAN")]),
    ])


# --------------------------------------------------------------------------- #
# 4. the single callback that drives the whole dashboard
# --------------------------------------------------------------------------- #
@app.callback(
    [Output("plot1", "children"), Output("plot2", "children"), Output("plot3", "children"),
     Output("plot4", "children"), Output("plot5", "children")],
    [Input("submit-button", "n_clicks")],
    [State("input-year", "value"), State("chart-type", "value")])
def update_dashboard(n_clicks, year, chart_type):
    df = airline_data[airline_data["Year"] == int(year)]

    if df.empty:
        msg = html.P(f"No flight records for {year}.")
        return [msg] * 5

    fig_h, margin = 400, dict(l=40, r=20, t=60, b=40)

    # ---------------------------- report type 1 ---------------------------- #
    if chart_type == 1:
        tree_data, pie_data, map_data, bar_data, line_data = compute_data_choice_1(df)

        tree_fig = px.treemap(tree_data, path=["DestState", "Reporting_Airline"],
                              values="Flights", color="Flights",
                              color_continuous_scale="RdBu",
                              title="Flight count by airline to destination state")
        tree_fig.update_layout(height=fig_h, margin=margin)

        pie_fig = px.pie(pie_data, values="Flights", names="OriginState",
                         title="Flight count by origin state")
        pie_fig.update_traces(textposition="inside", textinfo="percent+label")
        pie_fig.update_layout(height=fig_h, margin=margin)

        map_fig = px.choropleth(map_data, locations="OriginState",
                                locationmode="USA-states",
                                color="Flights", scope="usa",
                                color_continuous_scale="Viridis",
                                title="Flight count by origin state")
        map_fig.update_layout(height=fig_h, margin=margin)

        bar_fig = px.bar(bar_data, x="Month", y="Flights",
                         color="CancellationCode", barmode="group",
                         title="Cancellation count by month and cancellation code",
                         labels={"CancellationCode": "Cancellation code"})
        bar_fig.update_layout(height=fig_h, margin=margin,
                              xaxis=dict(tickmode="linear", tick0=1, dtick=1))

        line_fig = px.line(line_data, x="Month", y="AirTime",
                           color="Reporting_Airline", markers=True,
                           title="Average air time (minutes) by airline and month",
                           labels={"AirTime": "Average air time (min)"})
        line_fig.update_layout(height=fig_h, margin=margin,
                               xaxis=dict(tickmode="linear", tick0=1, dtick=1))

        return [dcc.Graph(figure=tree_fig), dcc.Graph(figure=pie_fig),
                dcc.Graph(figure=map_fig), dcc.Graph(figure=bar_fig),
                dcc.Graph(figure=line_fig)]

    # ---------------------------- report type 2 ---------------------------- #
    avg_car, avg_weather, avg_nas, avg_sec, avg_late = compute_data_choice_2(df)

    def delay_fig(data, column, title, color):
        fig = px.line(data, x="Month", y=column, color="Reporting_Airline",
                      markers=True, title=title,
                      labels={column: "Average delay (min)"})
        fig.update_layout(height=fig_h, margin=margin,
                          title_font_color=color,
                          xaxis=dict(tickmode="linear", tick0=1, dtick=1))
        return dcc.Graph(figure=fig)

    return [
        delay_fig(avg_car, "CarrierDelay", f"Average carrier delay time by airline - {year}", "#d62728"),
        delay_fig(avg_weather, "WeatherDelay", f"Average weather delay time by airline - {year}", "#1f77b4"),
        delay_fig(avg_nas, "NASDelay", f"Average NAS delay time by airline - {year}", "#2ca02c"),
        delay_fig(avg_sec, "SecurityDelay", f"Average security delay time by airline - {year}", "#9467bd"),
        delay_fig(avg_late, "LateAircraftDelay", f"Average late aircraft delay time by airline - {year}", "#ff7f0e"),
    ]


if __name__ == "__main__":
    app.run(debug=False, port=8055)
